import { getStore } from "@netlify/blobs";

const rounds = [
 {name:"Mystery Basket",questions:[
  ["Which herb is traditionally used to make pesto alla Genovese?",["Cilantro","Basil","Dill","Sage"],1],
  ["Which of these is an allium commonly used as an aromatic base in cooking?",["Celery","Onion","Carrot","Bell pepper"],1],
  ["What flavor does a lemon primarily contribute to a dish?",["Sweetness","Bitterness","Acidity","Umami"],2],
  ["Which spice is made from dried, ground berries of the Piper nigrum plant?",["Paprika","Black pepper","Cumin","Coriander"],1],
  ["Which fruit is known for containing mostly monounsaturated fat?",["Apple","Avocado","Pineapple","Grape"],1]
 ]},
 {name:"Food Safety Faceoff",questions:[
  ["What is the minimum internal temperature for poultry, including chicken breast?",["145°F","155°F","165°F","175°F"],2],
  ["What should you do first after handling raw chicken before preparing a salad?",["Wipe hands on a towel","Wash hands with soap and water","Put on an apron","Rinse the chicken"],1],
  ["Which refrigerator temperature is the safest target for cold food storage?",["50°F or below","45°F or below","40°F or below","32°F or below"],2],
  ["A large pot of soup needs to cool safely. Which approach is best?",["Leave it on the counter overnight","Divide it into shallow containers","Put the entire hot stockpot in a crowded refrigerator","Cover it tightly and leave it at room temperature"],1],
  ["What is the difference between cleaning and sanitizing a food-contact surface?",["They mean exactly the same thing","Cleaning removes soil; sanitizing reduces microorganisms","Sanitizing removes visible grease only","Cleaning kills every microorganism"],1]
 ]},
 {name:"Kitchen Knowledge",questions:[
  ["Which cooking method uses hot, dry air surrounding the food?",["Poaching","Steaming","Roasting","Simmering"],2],
  ["What does it mean to temper eggs in a custard recipe?",["Freeze them before mixing","Gradually add hot liquid while whisking","Whip them until stiff","Cook them directly over high heat"],1],
  ["What gas produced by yeast helps bread dough rise?",["Oxygen","Nitrogen","Carbon dioxide","Hydrogen"],2],
  ["Which classic mother sauce is made from milk thickened with a white roux?",["Velouté","Béchamel","Espagnole","Hollandaise"],1],
  ["What is a julienne cut?",["Small cubes","Thin matchstick-shaped strips","Large wedges","Finely chopped herbs"],1]
 ]},
 {name:"Chef's Challenge",questions:[
  ["A soup tastes too salty. Which adjustment is most likely to help balance it without simply adding more salt?",["Add an acidic ingredient gradually","Add more soy sauce","Reduce the soup further","Add salted butter"],0],
  ["A guest says they cannot consume dairy. Which ingredient is the best substitute for cow's milk in a smoothie?",["Plain almond beverage","Buttermilk","Whey powder","Sweetened condensed milk"],0],
  ["You are planning a meal for a guest with a severe peanut allergy. What is the safest first step?",["Remove visible peanuts only","Ask the guest and carefully verify ingredients and cross-contact controls","Use a different brand of peanut oil without checking","Assume the garnish is the only concern"],1],
  ["A pan sauce is too thin. Which technique can help thicken it while concentrating flavor?",["Dilute with stock","Simmer to reduce it","Add ice","Rinse the pan"],1],
  ["You are serving a composed salad for a group. Which action best supports consistent quality?",["Dress all salads hours ahead","Use varied portion sizes","Prepare components consistently and dress close to service","Leave cut produce uncovered"],2]
 ]}
];
const store = getStore({name:"chef-showdown-rooms",consistency:"strong"});
const json = (data,status=200)=>Response.json(data,{status,headers:{"cache-control":"no-store"}});
const random = n => {const b=new Uint8Array(n);crypto.getRandomValues(b);return [...b].map(x=>x.toString(16).padStart(2,"0")).join("")};
const code = ()=>{const chars="ABCDEFGHJKLMNPQRSTUVWXYZ23456789";let s="";for(let i=0;i<6;i++)s+=chars[Math.floor(Math.random()*chars.length)];return s};
async function withLock(room,fn){const key=`lock:${room}`;let acquired=false;for(let i=0;i<30;i++){const r=await store.set(key,JSON.stringify({at:Date.now(),nonce:random(6)}),{onlyIfNew:true});if(r.modified){acquired=true;break;}const held=await store.get(key,{type:"json"});if(held&&Date.now()-held.at>10000){await store.delete(key);continue;}await new Promise(resolve=>setTimeout(resolve,80+Math.random()*90));}if(!acquired)throw new Error("This room is busy. Please try again.");try{return await fn()}finally{await store.delete(key)}}
async function load(room){const x=await store.get(`room:${room}`,{type:"json"});if(!x||x.expires<Date.now())throw new Error("Room not found or expired.");return x}
async function save(room,state){state.updated=Date.now();await store.setJSON(`room:${room}`,state)}
function playerFor(s,token){return s.players.find(p=>p.token===token)}
function publicState(s,token){const me=playerFor(s,token);if(!me)throw new Error("You are not a member of this room.");const q=s.status==="playing"&&s.q<20?rounds[Math.floor(s.q/5)].questions[s.q%5]:null;const allAnswered=s.players.every(p=>p.answer!==null)||Date.now()>=s.deadline;return {code:s.code,status:s.status,players:s.players.map(p=>({id:p.id,name:p.name,score:p.score})),you:me.id,questionNumber:s.q+1,deadline:s.deadline,allAnswered,question:q?{roundName:rounds[Math.floor(s.q/5)].name,prompt:q[0],answers:q[1]}:null,myAnswer:me.answer,winner:s.winner||null}}
export default async (req)=>{
 if(req.method!=="POST")return json({error:"Use POST."},405);
 let body;try{body=await req.json()}catch{return json({error:"Invalid request."},400)}
 const {action,room,token}=body;
 try{
  if(action==="create"){
   const name=String(body.name||"Chef").trim().slice(0,18)||"Chef";let roomCode;let created=false;
   for(let i=0;i<8&&!created;i++){roomCode=code();const state={code:roomCode,status:"lobby",host:null,q:0,deadline:0,winner:null,expires:Date.now()+6*60*60*1000,players:[]};const t=random(24);state.host=t;state.players.push({id:random(8),token:t,name,score:0,answer:null});const wr=await store.set(`room:${roomCode}`,JSON.stringify(state),{onlyIfNew:true});if(wr.modified){created=true;return json({room:roomCode,token:t,state:publicState(state,t)})}}
   throw new Error("Could not create a room. Please try again.");
  }
  if(action==="join"){
   const c=String(body.room||"").toUpperCase().replace(/[^A-Z0-9]/g,"");if(!/^[A-Z0-9]{6}$/.test(c))throw new Error("Enter the six-character room code.");
   const result=await withLock(c,async()=>{const s=await load(c);if(s.status!=="lobby")throw new Error("This game has already started.");if(s.players.length>=8)throw new Error("This room is full.");const t=random(24);s.players.push({id:random(8),token:t,name:String(body.name||"Chef").trim().slice(0,18)||"Chef",score:0,answer:null});await save(c,s);return {room:c,token:t,state:publicState(s,t)}});return json(result);
  }
  if(!room||!token)throw new Error("Your room session is missing. Rejoin the room.");
  const result=await withLock(room,async()=>{const s=await load(room);const me=playerFor(s,token);if(!me)throw new Error("Your player session is no longer valid.");
   if(action==="state")return {state:publicState(s,token)};
   if(action==="start") {if(s.host!==token)throw new Error("Only the host can start the game.");if(s.status!=="lobby")throw new Error("The game has already started.");if(s.players.length<2)throw new Error("At least two players are needed.");s.status="playing";s.q=0;s.deadline=Date.now()+20000;s.players.forEach(p=>p.answer=null);await save(room,s);return {state:publicState(s,token)}}
   if(action==="answer") {if(s.status!=="playing")throw new Error("The game is not accepting answers.");if(Date.now()>s.deadline)throw new Error("Time is up for this question.");if(me.answer!==null)throw new Error("You have already answered.");const q=rounds[Math.floor(s.q/5)].questions[s.q%5];const a=Number(body.answer);if(!Number.isInteger(a)||a<0||a>3)throw new Error("Choose one of the four answers.");me.answer=a;if(a===q[2])me.score+=1000+Math.max(0,Math.round(500*(s.deadline-Date.now())/20000));await save(room,s);return {state:publicState(s,token)}}
   if(action==="next") {if(s.host!==token)throw new Error("Only the host can advance the game.");if(s.status!=="playing")throw new Error("The game is not active.");if(!s.players.every(p=>p.answer!==null)&&Date.now()<s.deadline)throw new Error("Wait until everyone has answered or time runs out.");if(s.q===19){s.status="finished";s.winner=[...s.players].sort((a,b)=>b.score-a.score)[0]?.name||"Chef";}else{s.q++;s.players.forEach(p=>p.answer=null);s.deadline=Date.now()+20000;}await save(room,s);return {state:publicState(s,token)}}
   throw new Error("Unknown action.");
  });return json(result);
 }catch(e){return json({error:e?.message||"Server error."},400)}
};
